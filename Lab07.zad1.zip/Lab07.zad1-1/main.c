#include <stdio.h>
#include <windows.h>
int main(int argc, char *argv[]) {
fflush(stdout);
SetConsoleOutputCP(CP_UTF8);
{
puts("\tA - wyświetla liczby 1, 2, 3...");
int i = 1;
while (i <= 10) {
printf("%2d\n", i);
i = i + 1;
}
}
fflush(stdin);
getchar();
{
puts("\n\tB - wyświetla liczby 1, 2, 3... inny zapis");
int i = 1;
while (i < 11)
printf("%2d\n", i++);
}
fflush(stdin);
getchar();
{
puts("\n\tC - wyświetla liczby 10, 9, 8...");
int i = 10;
while (i != 0) {
printf("%2d\n", i);
i = i - 1;
}
}
fflush(stdin);
getchar();
{
puts("\n\tD - wyświetla liczby 10, 9, 8... inny zapis");
int i = 10;
while (i)
printf("%2d\n", i--);
}
fflush(stdin);
getchar();
return 0;
}