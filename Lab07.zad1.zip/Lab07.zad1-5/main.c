#include <stdio.h>
#include <windows.h>
int main(int argc, char *argv[]) {
    SetConsoleOutputCP(CP_UTF8);
    fflush(stdout);
    puts("\tA - wyświetla liczby 1, 2, ..., 10");
    for (int i = 1; i <= 10; i++) {
        printf("%2d\n", i);
    }
    fflush(stdin);
    getchar();
    puts("\tB - wyświetla liczby 1, 2, ..., 10 - pusta instr. pętli");
    for (int i = 1; i <= 10; printf("%2d\n", i++));
    fflush(stdin);
    getchar();
    puts("\tC- wyświetla liczby 10, 9, ..., 1");
    {
        for (int j = 10; j != 0; j = j - 1)
            printf("%2d\n", j);
    }
    fflush(stdin);
    getchar();
    puts("\n\tD - wyświetla liczby 10, 9, ..., 1 - pusta instr. pętli");
    {
        for (int i = 10; i; printf("%2d\n", i--));
    }
    fflush(stdin);
    getchar();
    return 0;
}