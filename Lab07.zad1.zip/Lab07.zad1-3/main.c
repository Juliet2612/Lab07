#include <stdio.h>
#include <windows.h>
int main(int argc, char *argv[]) {
    SetConsoleOutputCP(CP_UTF8);
    fflush(stdout);
    puts("\tA - wyświetla liczby 1, 2, 3...");
    int i = 1;
    do {
        printf("%2d\n", i);
        i = i + 1;
    } while (i <= 10);
    fflush(stdin);
    getchar();
    puts("\n\tB - wyświetla liczby 1, 2, 3... inny zapis");
    i = 1;
    do
        printf("%2d\n", i);
    while (++i < 11);
    fflush(stdin);
    getchar();
    puts("\n\tC - wyświetla liczby 10, 9, 8...");
    i = 10;
    do {
        printf("%2d\n", i);
        i = i - 1;
    } while (i != 0);
    fflush(stdin);
    getchar();
    puts("\n\tD - wyświetla liczby 10, 9, 8... inny zapis");
    i = 10;
    do
        printf("%2d\n", i);
    while (--i);
    fflush(stdin);
    getchar();
    return 0;
}