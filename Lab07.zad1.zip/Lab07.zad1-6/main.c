#include <stdio.h>
#include <windows.h>
int main(int argc, char *argv[]) {
    SetConsoleOutputCP(CP_UTF8);
    fflush(stdout);
    int n, sumPos = 0, sumNeg = 0, counter = 0;
    puts("Program zlicza ilość i sumy szeregu liczb całkowitych różnych od zera.");
    puts("Podawaj liczby - 0 kończy szereg\n");
    for (;;) {
        printf("n = ");
        scanf("%d", &n);
        if (n == 0) break;
        if (n > 0) sumPos += n;
        else sumNeg += n;
        counter++;
    }
    if (counter == 0) {
        puts("\nNie wprowdzono żadnych liczb do sumowania.");
        fflush(stdin);
        getchar();
        return 0;
    }
    printf("\nŁączna ilość liczb: %d", counter);
    printf("\nSuma dodatnich: %d", sumPos);
    printf("\nSuma ujemnych: %d\n\n", sumNeg);
    fflush(stdin);
    getchar();
    return 0;
}